package interfaces;


public interface HashFunction<K> {
	int hashCode(K key);
}
