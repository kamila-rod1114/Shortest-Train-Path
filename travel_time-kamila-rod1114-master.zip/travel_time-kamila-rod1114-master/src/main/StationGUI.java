package main;
/**
 * @author Kamila S. Rodriguez Reyes
 * @version 21/4/2024
 * This class was created to make a GUI thats capable of visualizing the departure and arrival times on am/pm format
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

import data_structures.HashTableSC;
import data_structures.SimpleHashFunction;
import data_structures.ArrayList;
import data_structures.ArrayListStack;
import data_structures.HashSet;
import interfaces.Map;
import interfaces.Stack;
import interfaces.Set;
import interfaces.List;

public class StationGUI {
	
	private static Map<String, Double> departureTimes = new HashTableSC<String, Double>(1, new SimpleHashFunction<>());
	
	/**
	 * converts time to am/pm
	 * @param minutes
	 * @return the time in the correct format
	 */
	public static String minutesToAMPM(double minutes) {
		int totalHours = (int) minutes / 60;
		int remainderMins = (int) minutes % 60;
		String amOrPm = "am";
		if(totalHours >= 12) {
			amOrPm = "pm";
		}
		
		int resultingHour = totalHours % 12;
		if (resultingHour == 0) {
			resultingHour = 12;
		}
		
		return resultingHour + ":" + String.format("%02d", remainderMins) + " " + amOrPm;
		
	}
	
	/**
	 * This main method creates the actual GUI
	 * @param args
	 */
	public static void main(String[] args) {
		departureTimes.put("Bugapest", 575.0);
		departureTimes.put("Dubay", 630.0);
		departureTimes.put("Berlint", 1225.0);
		departureTimes.put("Mosbull", 1080.0);
		departureTimes.put("Cayro", 400.0);
		departureTimes.put("Bostin", 625.0);
		departureTimes.put("Los Angelos", 750.0);
		departureTimes.put("Dome", 810.0);
		departureTimes.put("Takyo", 935.0);
		departureTimes.put("Unstabul", 995.0);
		departureTimes.put("Chicargo", 1165.0);
		departureTimes.put("Loondun", 840.0);
		
		JFrame frame = new JFrame("Train Station Times!");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,300);
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Station");
        model.addColumn("Departure");
        model.addColumn("Arrival");
        
        TrainStationManager trains = new TrainStationManager("stations.csv");
        Map<String, Double> travelTimesMap = trains.getTravelTimes();
        System.out.println(travelTimesMap);
        
        for(int i = 0; i < travelTimesMap.size(); i++) {
        	String station = travelTimesMap.getKeys().get(i);
        	if(station == "Westside") continue;
        	String departure = minutesToAMPM(departureTimes.get(station));
        	String arrival = minutesToAMPM((departureTimes.get(station) + travelTimesMap.get(station)));
        	System.out.println(departure);
        	model.addRow(new String[] {station, departure, arrival});
        }
        
        JTable table = new JTable(model);
        table.setPreferredScrollableViewportSize(new Dimension(300,200));
        table.setFillsViewportHeight(true);
         
        JScrollPane scrollPane = new JScrollPane(table);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        
        frame.setVisible(true);
	}

}
