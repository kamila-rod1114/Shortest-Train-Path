package main;

import interfaces.List;
/**
 * @author Kamila S. Rodriguez Reyes
 * @version 4/15/2024
 * This class was created with the purpose of creating a train station manager 
 * that calculates things like travel time and shortest distance
 * This class was created with maps, hash tables, array List and stacks used in the different methods
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import data_structures.HashTableSC;
import data_structures.SimpleHashFunction;
import data_structures.ArrayList;
import data_structures.ArrayListStack;
import data_structures.HashSet;
import interfaces.Map;
import interfaces.Stack;
import interfaces.Set;

public class TrainStationManager {

	
	private Map<String, List<Station>> stations = new HashTableSC<String, List<Station>>(1, new SimpleHashFunction<>());
	private Map<String, Station> shortestMap = new HashTableSC<String, Station>(1, new SimpleHashFunction<>());
	private Map<String, Double> travelTimes = new HashTableSC<String, Double>(1, new SimpleHashFunction<>());
	
	/**
	 * 
	 * @param takes in station_file into the buffer reader, 
	 * it also calculates the distance to and from a specific station
	 */
	public TrainStationManager(String station_file) {
		try {
			BufferedReader brc;
			brc = new BufferedReader(new FileReader("inputFiles/" + station_file));
			String line = brc.readLine(); 
			line = brc.readLine(); // Added in case it reads first line: "src, dst, dist".
			while(line!=null) {
				String[] stationInfo = line.split(",");
				Station s1 = new Station(stationInfo[1], Integer.parseInt(stationInfo[2]));
				Station s2 = new Station(stationInfo[0], Integer.parseInt(stationInfo[2]));
				List<Station> value = stations.get(stationInfo[0]);
				List<Station> reverseValue = stations.get(stationInfo[1]);
				

				if(value == null) {
					value = new ArrayList<Station>(1);
					value.add(s1);
					stations.put(stationInfo[0], value);
				} else {
					value.add(s1);
					stations.put(stationInfo[0], value);
				}
				
				if(reverseValue == null) {
					reverseValue = new ArrayList<Station>(1);
					reverseValue.add(s2);
					stations.put(stationInfo[1], reverseValue);
				} else {
					reverseValue.add(s2);
					stations.put(stationInfo[1], reverseValue);
				}
		
				
				line = brc.readLine();
			}

			findShortestDistance();
			getTravelTimes();

			brc.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * looks through all the possible routes and finds the shortest distance to take 
	 */
	private void findShortestDistance() {
		
		List<String> stationKeys = stations.getKeys();
		
		for(int i = 0; i < stationKeys.size(); i++) {
			shortestMap.put(stationKeys.get(i), new Station("Westside", Integer.MAX_VALUE));
		}
		
		Stack<Station> toVisit = new ArrayListStack<Station>();
		Set<Station> visited = new HashSet<Station>();
		
		shortestMap.put("Westside", new Station("Westside", 0));
		toVisit.push(new Station("Westside", 0));
		
		
		while (!toVisit.isEmpty()) {
			Station currentStation = toVisit.pop();
			visited.add(currentStation);
			String curStationName = currentStation.getCityName();
			
			for(Station neighbor: stations.get(curStationName)) {
				
				if(neighbor == null) {
					break;
				}
				
				int stationsDistance = neighbor.getDistance();
				int dstFromWestsideMap = shortestMap.get(curStationName).getDistance();
				
				int dstBetweenStations = stationsDistance + dstFromWestsideMap;
				
				if(dstBetweenStations < shortestMap.get(neighbor.getCityName()).getDistance()){
					shortestMap.put(neighbor.getCityName(), new Station(curStationName, dstBetweenStations));
					
				}
				
				if (!visited.isMember(neighbor)) {
						sortStack(neighbor, toVisit);
				}
				
				
			}
		}
				
	}
	/**
	 * Takes in a value and puts it into a stack sorted in descending order
	 * @param station
	 * @param stackToSort
	 */
	public void sortStack(Station station, Stack<Station> stackToSort) {
		Stack<Station> tempStack = new ArrayListStack<Station>();
		
		while(!stackToSort.isEmpty() && station.getDistance() > stackToSort.top().getDistance()) {
			tempStack.push(stackToSort.pop());
		}
		stackToSort.push(station);
		while(!tempStack.isEmpty()) {
			stackToSort.push(tempStack.pop());
		}
	}
	/**
	 * 
	 * @return the time it takes to travel for Westside to another station
	 */
	public Map<String, Double> getTravelTimes() {
		List<String> stationKeys = shortestMap.getKeys();
		
		for(int i = 0; i < stationKeys.size(); i++) {
			int citiesTraversed = 0;
			String currentStation = shortestMap.get(stationKeys.get(i)).getCityName();
			
			while(currentStation != "Westside") {
				citiesTraversed++;
				currentStation = shortestMap.get(currentStation).getCityName();
			}
			
			double distance = shortestMap.get(stationKeys.get(i)).getDistance() * 2.5;
			travelTimes.put(stationKeys.get(i), (distance + (15 * citiesTraversed)));
			
		}
		
		return travelTimes;
	
	
		// 5 minutes per kilometer
		// 15 min per station
		
	}

	/**
	 * 
	 * @return a station
	 */
	public Map<String, List<Station>> getStations() {
		return stations;
		
	}

	/**
	 * sets the station in that city
	 * @param cities
	 */
	public void setStations(Map<String, List<Station>> cities) {
		stations = cities;
	}

	/**
	 * 
	 * @return returns the shortest route from Westside to another city
	 */
	public Map<String, Station> getShortestRoutes() {
		return shortestMap;
		
	}

	/**
	 * sets the shortest route from Westside to another city
	 * @param shortestRoutes
	 */
	public void setShortestRoutes(Map<String, Station> shortestRoutes) {
		shortestMap = shortestRoutes;
	}
	
	/**
	 * BONUS EXERCISE THIS IS OPTIONAL
	 * Returns the path to the station given. 
	 * The format is as follows: Westside->stationA->.....stationZ->stationName
	 * Each station is connected by an arrow and the trace ends at the station given.
	 * 
	 * @param stationName - Name of the station whose route we want to trace
	 * @return (String) String representation of the path taken to reach stationName.
	 */
	public String traceRoute(String stationName) {
		
		Stack<String> passedStations = new ArrayListStack<String>();
		while(stationName != "Westside") {
			passedStations.push(stationName);
			stationName = shortestMap.get(stationName).getCityName();
		}

		String str = "Westside";
		while(!passedStations.isEmpty()){
			str+= "->" + passedStations.pop();
		}

		return str;
	}
	
	/**
	 * main method used for testing
	 * @param args
	 */
	public static void main(String[] args) {
		TrainStationManager tsm = new TrainStationManager("stations.csv");

		System.out.println(tsm.getStations());
		
	
	}

}