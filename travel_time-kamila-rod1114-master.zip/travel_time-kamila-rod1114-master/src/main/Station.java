package main;
/**
 * @author Kamila S. Rodriguez Reyes
 * @version 4/15/2024
 * This class is created with the purpose of creating a station with its distance from a certain location to another
 */
public class Station {
	String cName;
	int dst;
	/* Creates a Station from the string given. The string has the name of a city
	 */
	
	/**
	 * 
	 * @param name where the station will be
	 * @param distance to a specific city to another
	 */
	public Station(String name, int dist) {
		cName = name;
		dst = dist;		
	
	}
	/**
	 * 
	 * @return City name
	 */
	public String getCityName() {
		return cName;
		
	}
	/**
	 * 
	 * @param takes city name and sets it when method gets called
	 */
	public void setCityName(String cityName) {
		cName = cityName;
		
	}
	/**
	 * 
	 * @return Distance between cities
	 */
	public int getDistance() {
		return dst;
		
	}
	/**
	 * 
	 * @param sets the distance between cities
	 */
	public void setDistance(int distance) {
		dst = distance;
		
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Station other = (Station) obj;
		return this.getCityName().equals(other.getCityName()) && this.getDistance() == other.getDistance();
	}
	@Override
	public String toString() {
		return "(" + this.getCityName() + ", " + this.getDistance() + ")";
	}
	/**
	 * main created to make testers to test the code
	 * @param args
	 */
	public static void main(String[] args) {
		Station test1 = new Station("Alaska", 31);
		System.out.println(test1.getCityName());
		System.out.println(test1.getDistance());
		test1.setCityName("NewYork");
		test1.setDistance(48);
		System.out.println(test1.getCityName());
		System.out.println(test1.getDistance());
		
	}

}
